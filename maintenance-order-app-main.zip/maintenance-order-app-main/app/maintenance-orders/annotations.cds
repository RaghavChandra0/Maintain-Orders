using MaintenanceService as service from '../../srv/maintenance-service';

annotate service.MaintenanceOrders with @(
  UI.SelectionFields: [ status, assignedWorkCenter ],
  UI.LineItem: [
    { Value: number,             Label: 'Order Number' },
    { Value: description,        Label: 'Description' },
    { Value: status,             Label: 'Status' },
    { Value: scheduledStartDate, Label: 'Start Date' },
    { Value: scheduledEndDate,   Label: 'End Date' },
    { Value: assignedWorkCenter, Label: 'Work Center' }
  ],
  UI.HeaderInfo: {
    TypeName:       'Maintenance Order',
    TypeNamePlural: 'Maintenance Orders',
    Title:       { Value: number },
    Description: { Value: description }
  }
);

annotate service.MaintenanceOrders with {
  number             @title: 'Order Number';
  description        @title: 'Description';
  status             @title: 'Status';
  scheduledStartDate @title: 'Scheduled Start';
  scheduledEndDate   @title: 'Scheduled End';
  assignedWorkCenter @title: 'Work Center';
}
