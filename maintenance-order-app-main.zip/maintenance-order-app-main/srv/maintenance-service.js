const cds = require('@sap/cds');
const LOG = cds.log('maintenance-service');

module.exports = cds.service.impl(async function (srv) {

  const external = await cds.connect.to('MaintenanceOrderService');

  srv.on('READ', 'MaintenanceOrders', req => {
    LOG.info('Fetching MaintenanceOrders from remote service');
    return external.run(req.query);
  });

  srv.on('READ', 'Operations', req => {
    LOG.info('Fetching Operations from remote service');
    return external.run(req.query);
  });

  srv.on('READ', 'Equipments', req => {
    LOG.info('Fetching Equipments from remote service');
    return external.run(req.query);
  });

  srv.on('READ', 'OrderDurations', req => {
    LOG.info('Fetching OrderDurations from remote service');
    return external.run(req.query);
  });

});
