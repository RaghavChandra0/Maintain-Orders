using { MaintenanceOrderService as external } from './external/MaintenanceOrderService';

@path: '/odata/v4/maintenance'
service MaintenanceService {

  @readonly
  entity MaintenanceOrders    as projection on external.MaintenanceOrder;

  @readonly
  entity Operations           as projection on external.Operation;

  @readonly
  entity Equipments           as projection on external.Equipment;

  @readonly
  entity OrderDurations       as projection on external.MaintenanceOrderDuration;

}
