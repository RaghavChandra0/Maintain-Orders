/**
 * srv/tools/maintenanceOrder.js
 * MCP tools for the Maintenance Order CAP service.
 *
 * Tools:
 *   1. get_maintenance_orders        – list all maintenance orders (with filters)
 *   2. get_maintenance_order_details – get a single order by ID
 *   3. get_operations                – list operations for an order
 *   4. get_equipments                – list all equipments
 *   5. get_order_durations           – get duration info for an order
 */

const cds = require("@sap/cds");
const { toMcpResult, toMcpError } = require("../lib/responseFormatter");

const LOG = cds.log("mcp-tools");

// ─── Tool 1: List maintenance orders ─────────────────────────────────────────

async function getMaintenanceOrders(input) {
  try {
    LOG.info("getMaintenanceOrders called", input);
    const svc = await cds.connect.to("MaintenanceOrderService");
    let query = SELECT.from("MaintenanceOrder");
    if (input.status) query = query.where({ status: input.status });
    if (input.assignedWorkCenter) query = query.where({ assignedWorkCenter: input.assignedWorkCenter });
    if (input.top) query = query.limit(input.top);
    const data = await svc.run(query);
    return toMcpResult(data);
  } catch (err) {
    return toMcpError(err);
  }
}

// ─── Tool 2: Get single maintenance order details ─────────────────────────────

async function getMaintenanceOrderDetails(input) {
  try {
    LOG.info("getMaintenanceOrderDetails called", input);
    const svc = await cds.connect.to("MaintenanceOrderService");
    const data = await svc.run(SELECT.one.from("MaintenanceOrder").where({ ID: input.orderID }));
    if (!data) return toMcpError(new Error(`Maintenance order not found: ${input.orderID}`));
    return toMcpResult(data);
  } catch (err) {
    return toMcpError(err);
  }
}

// ─── Tool 3: Get operations for an order ─────────────────────────────────────

async function getOperations(input) {
  try {
    LOG.info("getOperations called", input);
    const svc = await cds.connect.to("MaintenanceOrderService");
    let query = SELECT.from("Operation");
    if (input.orderID) query = query.where({ maintenanceOrder_ID: input.orderID });
    if (input.top) query = query.limit(input.top);
    const data = await svc.run(query);
    return toMcpResult(data);
  } catch (err) {
    return toMcpError(err);
  }
}

// ─── Tool 4: Get equipments ───────────────────────────────────────────────────

async function getEquipments(input) {
  try {
    LOG.info("getEquipments called", input);
    const svc = await cds.connect.to("MaintenanceOrderService");
    let query = SELECT.from("Equipment");
    if (input.location) query = query.where({ location: input.location });
    if (input.top) query = query.limit(input.top);
    const data = await svc.run(query);
    return toMcpResult(data);
  } catch (err) {
    return toMcpError(err);
  }
}

// ─── Tool 5: Get order durations ──────────────────────────────────────────────

async function getOrderDurations(input) {
  try {
    LOG.info("getOrderDurations called", input);
    const svc = await cds.connect.to("MaintenanceOrderService");
    let query = SELECT.from("MaintenanceOrderDuration");
    if (input.orderID) query = query.where({ number: input.orderID });
    const data = await svc.run(query);
    return toMcpResult(data);
  } catch (err) {
    return toMcpError(err);
  }
}

// ─── Tool registry ────────────────────────────────────────────────────────────

const maintenanceOrderTools = [
  {
    name: "get_maintenance_orders",
    description:
      "Get a list of maintenance orders. Optionally filter by status or assigned work center. " +
      "Returns order ID, number, description, status, scheduled start/end dates, and assigned work center.",
    inputSchema: {
      type: "object",
      properties: {
        status: { type: "string", description: "Filter by order status, e.g. 'REL', 'TECO', 'CLSD'." },
        assignedWorkCenter: { type: "string", description: "Filter by work center code." },
        top: { type: "number", description: "Maximum number of results to return. Default 50.", default: 50 },
      },
    },
    handler: getMaintenanceOrders,
  },
  {
    name: "get_maintenance_order_details",
    description:
      "Get the full details of a single maintenance order by its ID. " +
      "Returns order number, description, status, scheduling dates, and assigned work center.",
    inputSchema: {
      type: "object",
      properties: {
        orderID: { type: "string", description: "The ID of the maintenance order, e.g. '1' or '1000001'." },
      },
      required: ["orderID"],
    },
    handler: getMaintenanceOrderDetails,
  },
  {
    name: "get_operations",
    description:
      "Get all operations associated with a maintenance order. " +
      "Returns operation code, type, description, status, duration, and linked equipment.",
    inputSchema: {
      type: "object",
      properties: {
        orderID: { type: "string", description: "Filter operations by maintenance order ID." },
        top: { type: "number", description: "Maximum number of results. Default 50.", default: 50 },
      },
    },
    handler: getOperations,
  },
  {
    name: "get_equipments",
    description:
      "Get a list of equipment items. Optionally filter by location. " +
      "Returns equipment code, description, location, and location description.",
    inputSchema: {
      type: "object",
      properties: {
        location: { type: "string", description: "Filter by location code." },
        top: { type: "number", description: "Maximum number of results. Default 50.", default: 50 },
      },
    },
    handler: getEquipments,
  },
  {
    name: "get_order_durations",
    description:
      "Get the total duration information for a maintenance order. " +
      "Returns total duration value and time unit.",
    inputSchema: {
      type: "object",
      properties: {
        orderID: { type: "string", description: "The maintenance order number to get duration for." },
      },
    },
    handler: getOrderDurations,
  },
];

module.exports = { maintenanceOrderTools };
