/**
 * srv/mcp-service.js
 * CAP service handler for McpService (defined in mcp-service.cds).
 */

const cds = require("@sap/cds");
const { ALL_TOOLS } = require("./lib/mcpServer");

const LOG = cds.log("mcp-service");

module.exports = (srv) => {

  // GET /odata/v4/mcp/health()
  srv.on("health", () => {
    LOG.info("Health check called");
    return {
      status: "ok",
      tools: ALL_TOOLS.length,
      server: "Maintenance Order MCP Server",
    };
  });

  // GET /odata/v4/mcp/listTools()
  srv.on("listTools", () =>
    ALL_TOOLS.map(t => ({ name: t.name, description: t.description }))
  );

  // POST /odata/v4/mcp/callTool
  srv.on("callTool", async (req) => {
    const { toolName, arguments: argsInput } = req.data;
    LOG.info(`callTool: ${toolName}`);

    const tool = ALL_TOOLS.find(t => t.name === toolName);
    if (!tool) {
      return {
        success: false,
        result: null,
        error: `Tool not found: ${toolName}. Available: ${ALL_TOOLS.map(t => t.name).join(", ")}`,
      };
    }

    try {
      let args = {};
      if (typeof argsInput === "string") args = JSON.parse(argsInput);
      else if (typeof argsInput === "object" && argsInput !== null) args = argsInput;

      const result = await tool.handler(args);

      let parsedResult = result;
      if (result?.content && Array.isArray(result.content)) {
        const textContent = result.content.find(c => c.type === "text");
        if (textContent?.text) {
          try { parsedResult = JSON.parse(textContent.text); }
          catch { parsedResult = textContent.text; }
        }
      }

      return {
        success: true,
        result: typeof parsedResult === "string" ? parsedResult : JSON.stringify(parsedResult, null, 2),
        error: null,
      };
    } catch (err) {
      LOG.error(`Tool failed: ${toolName}`, err);
      return { success: false, result: null, error: err.message || String(err) };
    }
  });
};
