// CDS stub for the sample Maintenance Order OData V4 service.
// Fields derived from live $top=1 probing of each EntitySet.

@cds.external
service MaintenanceOrderService {

  @cds.external
  entity MaintenanceOrder {
    key ID                  : String;
        number              : String;
        description         : String;
        status              : String;
        scheduledStartDate  : DateTime;
        scheduledEndDate    : DateTime;
        assignedWorkCenter  : String;
  }

  @cds.external
  entity Operation {
    key ID                  : String;
        code                : String;
        type                : String;
        description         : String;
        status              : String;
        durationTime        : Integer;
        durationUnit        : String;
        maintenanceOrder_ID : String;
        equipment_ID        : String;
        operation_ID        : String;
  }

  @cds.external
  entity Equipment {
    key ID                  : String;
        code                : String;
        description         : String;
        location            : String;
        locationDescription : String;
  }

  @cds.external
  entity MaintenanceOrderDuration {
    key ID            : String;
        number        : String;
        totalDuration : Decimal;
        timeUnit      : String;
  }
}
