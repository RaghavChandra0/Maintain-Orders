/**
 * srv/server.js
 * CAP bootstrap — mounts MCP StreamableHTTP + SSE transports.
 *
 * MCP endpoints (Joule Studio uses StreamableHTTP):
 *   POST/GET/DELETE /mcp
 *   POST/GET/DELETE /odata/v4/mcp   ← Joule posts here
 *
 * SSE (legacy):
 *   GET  /sse
 *   POST /sse/message
 */

const cds = require("@sap/cds");
const express = require("express");
const { SSEServerTransport } = require("@modelcontextprotocol/sdk/server/sse.js");
const { StreamableHTTPServerTransport } = require("@modelcontextprotocol/sdk/server/streamableHttp.js");
const { buildMcpServer, ALL_TOOLS } = require("./lib/mcpServer");

const LOG = cds.log("mcp-server");

cds.on("bootstrap", async (app) => {
  app.use(express.json());

  // CORS helper
  const corsHeaders = (res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, Accept, mcp-session-id, last-event-id");
    res.setHeader("Access-Control-Expose-Headers", "mcp-session-id");
  };

  // ── StreamableHTTP (Joule Studio) ──────────────────────────────────────────
  const streamableTransports = {};

  const makeStreamableHandlers = (mountPath) => {
    app.post(mountPath, async (req, res) => {
      corsHeaders(res);
      try {
        const sessionId = req.headers["mcp-session-id"];
        let transport = sessionId ? streamableTransports[sessionId] : undefined;
        if (!transport) {
          transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
          const mcpServer = buildMcpServer();
          await mcpServer.connect(transport);
          if (transport.sessionId) {
            streamableTransports[transport.sessionId] = transport;
            res.setHeader("mcp-session-id", transport.sessionId);
          }
          LOG.info(`StreamableHTTP session: ${transport.sessionId ?? "stateless"}`);
        }
        await transport.handleRequest(req, res, req.body);
      } catch (err) {
        LOG.error("StreamableHTTP POST error:", err);
        if (!res.headersSent) res.status(500).json({ error: err.message });
      }
    });

    app.get(mountPath, async (req, res) => {
      corsHeaders(res);
      const sessionId = req.headers["mcp-session-id"];
      const transport = sessionId ? streamableTransports[sessionId] : undefined;
      if (!transport) {
        res.status(400).json({ error: "No active session. Send POST first." });
        return;
      }
      try { await transport.handleRequest(req, res); }
      catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); }
    });

    app.delete(mountPath, async (req, res) => {
      corsHeaders(res);
      const sessionId = req.headers["mcp-session-id"];
      const transport = sessionId ? streamableTransports[sessionId] : undefined;
      if (transport) {
        try { await transport.handleRequest(req, res); } catch { /* ignore */ }
        delete streamableTransports[sessionId];
      } else {
        res.status(204).end();
      }
    });

    app.options(mountPath, (_req, res) => { corsHeaders(res); res.status(204).end(); });
  };

  makeStreamableHandlers("/mcp");
  makeStreamableHandlers("/odata/v4/mcp");
  LOG.info(`MCP StreamableHTTP mounted at /mcp and /odata/v4/mcp — ${ALL_TOOLS.length} tools`);

  // ── SSE (legacy clients) ───────────────────────────────────────────────────
  const sseTransports = {};

  app.get("/sse", async (req, res, next) => {
    corsHeaders(res);
    if (!(req.headers["accept"] || "").includes("text/event-stream")) { next(); return; }
    try {
      const transport = new SSEServerTransport("/sse/message", res);
      sseTransports[transport.sessionId] = transport;
      const mcpServer = buildMcpServer();
      res.on("close", async () => {
        delete sseTransports[transport.sessionId];
        try { await mcpServer.close(); } catch { /* ignore */ }
      });
      await mcpServer.connect(transport);
      LOG.info(`SSE session: ${transport.sessionId}`);
    } catch (err) {
      if (!res.headersSent) res.status(500).end();
    }
  });

  app.post("/sse/message", async (req, res) => {
    corsHeaders(res);
    const sessionId = req.query["sessionId"];
    const transport = sseTransports[sessionId];
    if (!transport) {
      res.status(400).json({ error: "No active SSE session: " + sessionId });
      return;
    }
    try { await transport.handlePostMessage(req, res, req.body); }
    catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); }
  });

  app.options("/sse", (_req, res) => { corsHeaders(res); res.status(204).end(); });
  app.options("/sse/message", (_req, res) => { corsHeaders(res); res.status(204).end(); });
  LOG.info("MCP SSE transport mounted at /sse");
});

module.exports = cds.server;
