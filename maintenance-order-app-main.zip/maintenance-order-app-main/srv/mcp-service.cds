// srv/mcp-service.cds
// CAP service definition for the Maintenance Order MCP Server.
// Exposes health-check, tool listing, and tool execution endpoints.

namespace maintenance.mcp;

@path: '/odata/v4/mcp'
@protocol: 'odata-v4'
service McpService {

  // Health check — GET /odata/v4/mcp/health()
  function health() returns {
    status      : String;
    tools       : Integer;
    server      : String;
  };

  // List tools — GET /odata/v4/mcp/listTools()
  function listTools() returns array of {
    name        : String;
    description : String;
  };

  // Call tool — POST /odata/v4/mcp/callTool
  action callTool(
    toolName  : String,
    arguments : String   // JSON string of arguments
  ) returns {
    success : Boolean;
    result  : LargeString;
    error   : String;
  };
}
