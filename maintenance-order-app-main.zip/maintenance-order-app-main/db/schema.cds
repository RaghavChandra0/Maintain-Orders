// Pure proxy app — no local persistence.
// Placeholder to satisfy CDS model loading.
namespace maintenance.app;
